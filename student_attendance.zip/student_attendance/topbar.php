<style>
.navbar {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 40px;
  background: #129cff;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.logo {
  margin: auto;
  font-size: 20px;
  background: white;
  padding: 7px 11px;
  border-radius: 50% 50%;
  color: #000000b3;
}

.head-title {
  font-size: 18px;
  margin: auto;
}


</style>
<!-- navbar-light fixed-top bg-primary -->
<nav class="navbar">
  <div class="container-fluid">
  	<div class="col-lg-12">
  		<div class="col-md-1" style="display: flex;">
  		
  		</div>
      <div class="col-md-4 float-left text-white">
        <!-- ?php echo isset($_SESSION['system']['name']) ? $_SESSION['system']['name'] : '' ?> -->
        <h1 class="head-title">GSA Web Attendance Monitoring System</h1>
      </div>
	  	<div class="float-right">
        <div class=" dropdown mr-4">
            <a href="#" class="text-white dropdown-toggle"  id="account_settings" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['login_name'] ?> </a>
              <div class="dropdown-menu" aria-labelledby="account_settings" style="left: -2.5em;">
                <a class="dropdown-item" href="javascript:void(0)" id="manage_my_account"><i class="fa fa-cog"></i> Manage Account</a>
                <a class="dropdown-item" href="ajax.php?action=logout"><i class="fa fa-power-off"></i> Logout</a>
              </div>
        </div>
      </div>
  </div>
  
</nav>

<script>
  $('#manage_my_account').click(function(){
    uni_modal("Manage Account","manage_user.php?id=<?php echo $_SESSION['login_id'] ?>&mtype=own")
  })
</script>